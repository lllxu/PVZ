﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;
    private AudioSource au;//音频组件
    void Start()
    {
        au = GetComponent<AudioSource>();//获取音频组件
    }
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// 播放特效音乐
    /// </summary>
    public void PlayEFAudio(AudioClip clip)
    {
        // 从对象池获取一个音效物体
        EFAudio ef  = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.EFAudio).GetComponent<EFAudio>();
        ef.Init(clip);
    }

    public void sound_contral()
    {
        if (au.isPlaying)//正在播放背景音乐时
        {
            au.enabled = false;//取消该组件
                               //方式二 au.Stop();
        }
        else//未播放背景音乐时
        {
            au.enabled = true;//激活该组件
                              //方式二 au.Play();
        }
    }
}
