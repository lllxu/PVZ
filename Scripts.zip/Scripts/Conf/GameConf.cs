﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName ="GameConf",menuName ="GameConf")]
public class GameConf : ScriptableObject
{

    [Header("音乐")]
    public GameObject EFAudio;
    public AudioClip ButtonClick;
    public AudioClip Pause;
    public AudioClip Shovel;
    public AudioClip Place;
    public AudioClip SunClick;
    public AudioClip Boom;

    public AudioClip ZombieEat;
    public AudioClip ZombieHurtForPea;
    public AudioClip ZombieHurtForFire;
    public AudioClip ZombieGroan;

    public AudioClip GameOver;


    [Header("植物")]
    [Tooltip("除草机")]
    public GameObject LawnCleaner;
    [Tooltip("阳光")]
    public GameObject Sun;
    [Tooltip("太阳花")]
    public GameObject SunFlower;
    [Tooltip("豌豆射手")]
    public GameObject Peashooter;
    [Tooltip("坚果")]
    public GameObject WallNut;
    [Tooltip("地刺")]
    public GameObject Spike;
    [Tooltip("樱桃")]
    public GameObject Cherry;
    [Tooltip("双发豌豆")]
    public GameObject Repeater;
    [Tooltip("三发豌豆")]
    public GameObject Threepeater;
    [Tooltip("寒冰豌豆")]
    public GameObject SnowPea;
    [Tooltip("大嘴花")]
    public GameObject Chomper;
    [Tooltip("倭瓜")]
    public GameObject Squash;
    [Tooltip("超级大嘴花")]
    public GameObject BigChomper;
    [Tooltip("火炬树桩")]
    public GameObject TorchWood;
    [Tooltip("机枪射手")]
    public GameObject GatlingShooter;
    [Tooltip("高坚果")]
    public GameObject TallWallNut;
    [Tooltip("石地刺")]
    public GameObject Spikerock;
    [Tooltip("双子太阳花")]
    public GameObject TwinSunflower;
    [Tooltip("地刺坚果")]
    public GameObject TenManNut;
    [Tooltip("阳光菇")]
    public GameObject SunShroom;
    [Tooltip("胆小菇")]
    public GameObject ScaredyShroom;
    [Tooltip("裂荚豌豆")]
    public GameObject SplitPea;

    [Header("僵尸")]
    [Tooltip("僵尸的头")]
    public GameObject Zombie_Head;
    [Tooltip("僵尸的身体")]
    public GameObject Zombie_DieBody;
    [Tooltip("庶民僵尸的头")]
    public GameObject oCZombie_Head;
    [Tooltip("庶民僵尸的身体")]
    public GameObject oCZombie_DieBody;
    [Tooltip("舞狮僵尸的头")]
    public GameObject LionDanceZombie_Head;
    [Tooltip("舞狮僵尸的身体")]
    public GameObject LionDanceZombie_DieBody;
    [Tooltip("读报僵尸的头")]
    public GameObject NewspaperZombie_Head;
    [Tooltip("读报僵尸的身体")]
    public GameObject NewspaperZombie_DieBody;
    [Tooltip("撑杆跳僵尸的头")]
    public GameObject PoleVaultingZombie_Head;
    [Tooltip("撑杆跳僵尸的身体")]
    public GameObject PoleVaultingZombie_DieBody;
    [Tooltip("普通僵尸")]
    public GameObject Zombie;
    [Tooltip("庶民僵尸")]
    public GameObject oCZombie;
    [Tooltip("旗帜僵尸")]
    public GameObject FlagZombie;
    [Tooltip("路障僵尸")]
    public GameObject ConeheadZombie;
    [Tooltip("读报僵尸")]
    public GameObject NewspaperZombie;
    [Tooltip("报报僵尸")]
    public GameObject NNewspaperZombie;
    [Tooltip("铁桶僵尸")]
    public GameObject BucketheadZombie;
    [Tooltip("庶民铁桶僵尸")]
    public GameObject oCBucketheadZombie;
    [Tooltip("庶民路障僵尸")]
    public GameObject oCConeheadZombie;
    [Tooltip("胡子僵尸")]
    public GameObject MustacheZombie;
    [Tooltip("撑杆跳僵尸")]
    public GameObject PoleVaultingZombie;
    [Tooltip("撑撑杆跳僵尸")]
    public GameObject PPoleVaultingZombie;
    [Tooltip("舞狮僵尸")]
    public GameObject LionDanceZombie;
    [Tooltip("舞狮狮子僵尸")]
    public GameObject LLionZombie;
    [Tooltip("橄榄球僵尸")]
    public GameObject New1;
    [Tooltip("CX僵尸的头")]
    public GameObject CXZombie_Head;
    [Tooltip("comboni僵尸的身体")]
    public GameObject ComboniZombie_DieBody;
    [Tooltip("comboni2僵尸的身体")]
    public GameObject ComboniZombie2_DieBody;
    [Tooltip("CX僵尸的身体")]
    public GameObject CXZombie_DieBody;
    [Tooltip("橄榄球僵尸的身体")]
    public GameObject football_2Zombie_DieBody;
    [Tooltip("橄榄球僵尸变种的身体")]
    public GameObject Zombie_DieBodynew1;
    [Tooltip("橄榄球僵尸变种")]
    public GameObject football_2;
    [Tooltip("CX僵尸")]
    public GameObject CX;
    [Tooltip("Comboni僵尸")]
    public GameObject Comboni;
    [Tooltip("Comboni2僵尸")]
    public GameObject Comboni_2;
    [Tooltip("皇帝僵尸")]
    public GameObject Emperor;
    [Tooltip("皇帝僵尸死亡")]
    public GameObject Emperor_DieBody;
    [Tooltip("虾兵僵尸")]
    public GameObject XB;
    [Tooltip("虾兵僵尸的头")]
    public GameObject XB_Head;
    [Tooltip("虾兵僵尸的身体")]
    public GameObject XB_DieBody;
    [Tooltip("垃圾桶僵尸")]
    public GameObject TrushZombie;
    [Tooltip("小丑僵尸")]
    public GameObject JackinTheBoxZombie;
    [Tooltip("小丑僵尸的头")]
    public GameObject JackinTheBoxZombie_Head;
    [Tooltip("小丑僵尸的身体")]
    public GameObject JackinTheBoxZombie_DieBody;


    [Header("子弹")]
    [Tooltip("豌豆")]
    public GameObject Bullet1;
    [Tooltip("豌豆正常")]
    public Sprite Bullet1Nor;
    [Tooltip("豌豆击中")]
    public Sprite Bullet1Hit;
    [Tooltip("爆炸效果")]
    public GameObject BoomObj;
    [Tooltip("寒冰豌豆")]//10.12添加寒冰子弹
    public GameObject IceBullet;
    [Tooltip("豌豆正常")]
    public Sprite IceBulletNor;
    [Tooltip("豌豆击中")]
    public Sprite IceBulletHit;
    [Tooltip("爆炸效果")]
    public GameObject IceBoomObj;
    [Tooltip("火焰子弹")]
    public GameObject FireBullet;
    [Tooltip("击中火焰")]
    public Sprite FireBulletHit;
    [Tooltip("正常火焰")]
    public Sprite FireBulletNor;
    [Tooltip("蘑菇子弹")]
    public GameObject ShroomBullet;
    [Tooltip("蘑菇子弹正常")]
    public Sprite ShroomBulletNor;
    [Tooltip("蘑菇子弹击中")]
    public Sprite ShroomBulletHit;

}
