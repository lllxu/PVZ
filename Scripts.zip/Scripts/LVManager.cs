﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;//11.21
using UnityEngine.UI;//11.21
/// <summary>
/// 关卡状态
/// </summary>
public enum LVState
{ 
    // 开始游戏
    Start,
    // 战斗中
    Figth,
    // 结束
    Over
}

public class LVManager : MonoBehaviour
{
    public static LVManager Instance;
    private LVState currLVState;
    public int typeFlag = StartSceneManager.Instance.typeFlag;//11.21选择是小游戏还是无尽关卡
    private bool isOver;
    // 在刷新僵尸中
    private bool isUpdateZombie;

    // 当前第几天 关卡数
    private int currLV;
    // 关卡中的阶段 波数
    private int stageInLV;

    private UnityAction LVStartAction;

    public int maxStageInLV;//11.17 设定每关波数为关卡数的平方根+1

    public LVState CurrLVState { get => currLVState;
        set {
            currLVState = value;
            switch (currLVState)
            {
                case LVState.Start:
                    // 隐藏UI主面板
                    UIManager.Instance.SetMainPanelActive(false);
                    UIManager.Instance.SetChoseCardActiv(false);            //新:隐藏选择植物面板
                    UIManager.Instance.SetCancleCardActiv(false);            //新:隐藏取消选择按钮
                    // 刷新僵尸秀的僵尸
                    if (typeFlag == 0)//11.21
                    // 刷新僵尸秀的僵尸
                    {
                        if (currLV < 50)
                        {
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.Zombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.ConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.BucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCBucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCZombie);
                        }
                        else if (currLV >= 50 && currLV < 100)
                        {
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.Zombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.ConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.BucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCBucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.MustacheZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.LionDanceZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.LLionZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.NNewspaperZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.JackinTheBoxZombie);
                        }
                        else if (currLV >= 100 && currLV < 150)
                        {
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCBucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCZombie);
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.MustacheZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.LionDanceZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.LLionZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.NNewspaperZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.PPoleVaultingZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.New1);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.football_2);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.JackinTheBoxZombie);
                        }
                        else if (currLV >= 150 && currLV < 300)
                        {
                            ZombieManager.Instance.UpdateZombie(4, ZombieType.football_2);
                        //    ZombieManager.Instance.UpdateZombie(2, ZombieType.Comboni_2);
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.XB);
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.TrushZombie);
                         //   ZombieManager.Instance.UpdateZombie(2, ZombieType.Comboni);
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.New1);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.JackinTheBoxZombie);
                        }
                        else
                        {
                            ZombieManager.Instance.UpdateZombie(2, ZombieType.Zombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.ConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.BucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCBucketheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCConeheadZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.oCZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.MustacheZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.LionDanceZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.LLionZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.NNewspaperZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.football_2);
                       //     ZombieManager.Instance.UpdateZombie(1, ZombieType.Comboni_2);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.XB);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.TrushZombie);
                       //     ZombieManager.Instance.UpdateZombie(1, ZombieType.Comboni);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.New1);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.JackinTheBoxZombie);
                            ZombieManager.Instance.UpdateZombie(1, ZombieType.Emperor);
                        }
                    }
                    else//11.21
                    {
                        switch (currLV)
                        {
                            case 1:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.Zombie);
                                break;
                            case 2:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.ConeheadZombie);
                                break;
                            case 3:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.BucketheadZombie);
                                break;
                            case 4:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.oCZombie);
                                break;
                            case 5:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.oCBucketheadZombie);
                                break;
                            case 6:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.oCConeheadZombie);
                                break;
                            case 7:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.MustacheZombie);
                                break;
                            case 8:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.LionDanceZombie);
                                break;
                            case 9:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.LLionZombie);
                                break;
                            case 10:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.NNewspaperZombie);
                                break;
                            case 11:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.PPoleVaultingZombie);
                                break;
                            case 12:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.New1);
                                break;
                            case 13:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.football_2);
                                break;
                            case 14:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.CX);
                                break;
                            case 15:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.Comboni);
                                break;
                            case 16:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.Comboni_2);
                                break;
                            case 17:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.XB);
                                break;
                            case 18:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.TrushZombie);
                                break;
                            case 19:
                                ZombieManager.Instance.UpdateZombie(5, ZombieType.Emperor);
                                break;
                        }
                    }
                    // 摄像机移动到右侧观察关卡僵尸
                    Camera_C.Instance.StartMove(LVStartCameraBackAction);

                    break;
                case LVState.Figth:
                    // 显示主面板
                    UIManager.Instance.SetMainPanelActive(true);
                    // 20秒以后刷一只僵尸
                 
                    break;
                case LVState.Over:
                    break;
            }
        }
    }

    public int StageInLV { get => stageInLV;
        set {
            stageInLV = value;
            UIManager.Instance.UpdateStageNum(stageInLV - 1);
            if (stageInLV > maxStageInLV)
            {
                // 杀掉当前关卡的全部僵尸，就进入下一天
                ZombieManager.Instance.AddAllZombieDeadAction(OnAllZombieDeadAction);
                CurrLVState = LVState.Over;
            }
           
        }
    }
    public int CurrLV
    {
        get => currLV;
        set
        {
            currLV = value;
            StartLV(currLV);
        }
    }
    private void Awake()
    {
        Instance = this;
    }
    private void Start()//11.21
    {
        if (typeFlag == 0)
            CurrLV = SelectLevel.Instance.lv;
        else
            CurrLV = 1;
    }
    // 开始关卡
    public void StartLV(int lv)
    {
        if (isOver) return;
        currLV = lv;
        maxStageInLV = (int)System.Math.Sqrt((double)currLV) + 1;//11.17 设定每关波数为关卡数的平方根+1
        UIManager.Instance.UpdateDayNum(currLV);
        StageInLV = 1;
        CurrLVState = LVState.Start;
    }
    private void Update()
    {
        if (isOver) return;
        FSM();
    }
    public void FSM()
    {
        switch (CurrLVState)
        {
            case LVState.Start:
                break;
            case LVState.Figth:
                // 刷僵尸
                // 如果没有在刷新僵尸，则再刷新一波
                if (isUpdateZombie == false)
                {
                    // 僵尸刷新的时间
                    float updateTime;
                    if (currLV < 100)
                        updateTime = Random.Range(20 - stageInLV / 2, 25 - stageInLV / 2);//11.17
                    else if (currLV >= 100 && currLV < 500)
                        updateTime = Random.Range(35 - stageInLV, 40 - stageInLV);
                    else
                        updateTime = Random.Range(30, 60);
                    if (StageInLV == 1)
                    {
                        updateTime = 3;
                    }
                    // 僵尸刷新的数量
                    int updateNum = Random.Range(maxStageInLV * 2, maxStageInLV * 3);//11.17
                    UpdateZombie(updateTime, updateNum);
                }
                break;
            case LVState.Over:
                break;
        }
    }
    /// <summary>
    /// 关卡开始时 摄像机回归后要执行的方法
    /// </summary>
    private void LVStartCameraBackAction()
    {
        // 让阳光开始创建
        SkySunManager.Instance.StartCreatSun(6);
        // 开始显示UI特效
        UIManager.Instance.ShowLVStartEF();
        // 清理掉僵尸
        ZombieManager.Instance.ClearZombie();
        CurrLVState = LVState.Figth;

        // 关卡开始时需要做的事情
        if (LVStartAction != null) LVStartAction();

    }
    /// <summary>
    /// 更新僵尸
    /// </summary>
    private void UpdateZombie(float delay,int zombieNum)
    {
        StartCoroutine(DoUpdateZombie(delay, zombieNum));
    }

    IEnumerator DoUpdateZombie(float delay, int zombieNum)
    {
        isUpdateZombie = true;
        yield return new WaitForSeconds(delay);
        if (StageInLV == maxStageInLV)
        { ZombieManager.Instance.UpdateZombie(1, ZombieType.FlagZombie); }
        if (typeFlag == 0)//11.21
        {
            if (currLV < 50)
            {
                int num = zombieNum / 6;
                ZombieManager.Instance.UpdateZombie(zombieNum - num * 6, ZombieType.Zombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.ConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.BucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCBucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCZombie);
            }
            else if (currLV >= 50 && currLV < 100)
            {
                int num = zombieNum / 10;
                ZombieManager.Instance.UpdateZombie(zombieNum - num * 10, ZombieType.Zombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.ConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.BucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCBucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.MustacheZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.LionDanceZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.LLionZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.NNewspaperZombie);
                ZombieManager.Instance.UpdateZombie(1, ZombieType.JackinTheBoxZombie);
            }
            else if (currLV >= 100 && currLV < 150)
            {
                int num = zombieNum / 10;
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCBucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCZombie);
                ZombieManager.Instance.UpdateZombie(zombieNum - num * 10, ZombieType.MustacheZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.LionDanceZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.LLionZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.NNewspaperZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.PPoleVaultingZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.New1);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.football_2);
                ZombieManager.Instance.UpdateZombie(2, ZombieType.JackinTheBoxZombie);
            }
            else if (currLV >= 150 && currLV < 300)
            {
                int num = zombieNum / 6;
                ZombieManager.Instance.UpdateZombie(zombieNum - num * 6, ZombieType.football_2);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.Comboni_2);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.XB);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.TrushZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.Comboni);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.New1);
                ZombieManager.Instance.UpdateZombie(3, ZombieType.JackinTheBoxZombie);
            }
            else
            {
                int num = zombieNum / 15;
                ZombieManager.Instance.UpdateZombie(zombieNum - num * 15, ZombieType.Zombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.ConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.BucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCBucketheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCConeheadZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.oCZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.MustacheZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.LionDanceZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.LLionZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.NNewspaperZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.football_2);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.Comboni_2);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.XB);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.TrushZombie);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.Comboni);
                ZombieManager.Instance.UpdateZombie(num, ZombieType.New1);
                ZombieManager.Instance.UpdateZombie(3, ZombieType.JackinTheBoxZombie);
                ZombieManager.Instance.UpdateZombie(Random.Range(currLV / 100, currLV / 50), ZombieType.Emperor);
            }
        }
        else//11.21
        {
            switch (currLV)
            {
                case 1:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.Zombie);
                    break;
                case 2:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.ConeheadZombie);
                    break;
                case 3:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.BucketheadZombie);
                    break;
                case 4:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.oCZombie);
                    break;
                case 5:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.oCBucketheadZombie);
                    break;
                case 6:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.oCConeheadZombie);
                    break;
                case 7:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.MustacheZombie);
                    break;
                case 8:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.LionDanceZombie);
                    break;
                case 9:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.LLionZombie);
                    break;
                case 10:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.NNewspaperZombie);
                    break;
                case 11:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.PPoleVaultingZombie);
                    break;
                case 12:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.New1);
                    break;
                case 13:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.football_2);
                    break;
                case 14:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.CX);
                    break;
                case 15:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.Comboni);
                    break;
                case 16:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.Comboni_2);
                    break;
                case 17:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.XB);
                    break;
                case 18:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.TrushZombie);
                    break;
                case 19:
                    ZombieManager.Instance.UpdateZombie(zombieNum, ZombieType.Emperor);
                    break;
            }
        }
        ZombieManager.Instance.ZombieStartMove();
        isUpdateZombie = false;
        StageInLV += 1;
    }
    /// <summary>
    /// 添加关卡开始事件的监听者
    /// </summary>
    public void AddLVStartActionLinstener(UnityAction action)
    {
        LVStartAction += action;
    }

    /// <summary>
    /// 当全部僵尸死亡时触发的事件
    /// </summary>
    private void OnAllZombieDeadAction()
    {
        // 更新天数
        CurrLV += 1;
        maxStageInLV = (int)System.Math.Sqrt((double)currLV) + 1;//11.17 设定每关波数为关卡数的平方根+1
        // 执行一次之后，自己移除委托
        ZombieManager.Instance.RemoveAllZombieDeadAction(OnAllZombieDeadAction);
        //清空UI主面板内的所有卡片 --------------------新；
        CancleCard.Instance.CancleAll();
    }

    /// <summary>
    /// 游戏结束
    /// </summary>
    public void GameOver()
    {
        StopAllCoroutines();
        // 效果d
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ZombieEat);
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.GameOver);

        isOver = true;
        // 逻辑
        SkySunManager.Instance.StopCreatSun();
        ZombieManager.Instance.ClearZombie();

        // UI
        UIManager.Instance.GameOver();
    }
}
