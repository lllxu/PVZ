﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigChomper : PlantBase
{
    public override float MaxHp => 300;
    //初始化状态
    public int state = 1;
    //消化时间
    protected override float attackCD => 21;

    private string animationName;

    protected override Vector2 offset => new Vector2(0.29f, 0.19f);

    // 是否可以攻击
    private bool canAttack;

    protected override void OnInitForPlace()
    {
        canAttack = true;
        // 每秒检测有没有敌人被我攻击
        Calanimator();
        InvokeRepeating("CheckAttack", 0, 0.25f);
       
    }
    /// <summary>
    /// 检测攻击
    /// </summary>
    private void CheckAttack()
    {
        Calanimator();
        if (canAttack == false) return;
        //判断前面附近有没有僵尸
        List<ZombieBase> zombies = ZombieManager.Instance.GetZombies((int)currGrid.Point.y, transform.position, 3f);
        if (zombies.Count == 0) return;
        state = 2;
        Calanimator();
        StartCoroutine(Calstate3(zombies));
        //进入cd
        CDEnter();
        canAttack = false;

    }
    //避免状态2和3重叠
    IEnumerator Calstate3(List<ZombieBase> zombies)
    {

        yield return new WaitForSeconds(1.5f);
        zombies[0].Dead();
        state = 3;
        Calanimator();

    }
    private void Calanimator()
    {
        //正常状态
        if (state == 1)
        {
            animationName = "BigChomper_Idel";
        }
        //攻击状态
        else if (state == 2)
        {
            animationName = "BigChomper_Attack";
        }
        //消化状态
        else
        {
            animationName = "BigChomper_Digest";
        }
        animator.Play(animationName);
    }
    /// <summary>
    /// 进入CD
    /// </summary>
    private void CDEnter()
    {
        StartCoroutine(CalCD());
    }
    /// <summary>
    /// 计算冷却时间
    /// </summary>
    IEnumerator CalCD()
    {

        yield return new WaitForSeconds(attackCD);
        state = 1;
        canAttack = true;

    }
}
