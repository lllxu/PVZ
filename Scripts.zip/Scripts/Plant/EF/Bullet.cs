﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    //记录一开始的y坐标
    private float y;
    //判断直飞
    private bool CanDown;
    private bool CanUp;
    private Rigidbody2D rigidbody;
    private SpriteRenderer spriteRenderer;
    // 攻击力
    private int attackValue;
    // 是否击中
    private bool isHit;
    void Start()
    {
        CanDown = false;
        CanUp = false;
        isHit = false;
    }
    //子弹直飞
    public void Init(int attackValue, Vector2 pos)
    {

        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // 修改成正常状态的图片
        spriteRenderer.sprite = GameManager.Instance.GameConf.Bullet1Nor;
    }
    //子弹向左飞
    public void Initleft(int attackValue, Vector2 pos)
    {

        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.left * 300);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // 修改成正常状态的图片
        spriteRenderer.sprite = GameManager.Instance.GameConf.Bullet1Nor;
    }
    //子弹先斜上飞再直飞
    public void Init2(int attackValue, Vector2 pos)
    {
        this.y = pos.y;
        CanDown = true;
        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        rigidbody.AddForce(Vector2.up * 150);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // 修改成正常状态的图片
        spriteRenderer.sprite = GameManager.Instance.GameConf.Bullet1Nor;
    }
    //子弹先斜下飞再直飞
    public void Init3(int attackValue, Vector2 pos)
    {
        this.y = pos.y;
        CanUp = true;
        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        rigidbody.AddForce(Vector2.down * 150);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // 修改成正常状态的图片
        spriteRenderer.sprite = GameManager.Instance.GameConf.Bullet1Nor;
    }
    void Update()
    {
        if (isHit) return;
        if (transform.position.y - y >= 1.50f && CanDown)
        {
            CanDown = false;
            rigidbody.AddForce(Vector2.down * 150);
        }
        if (transform.position.y - y <= -1.50f && CanUp)
        {
            CanUp = false;
            rigidbody.AddForce(Vector2.up * 150);
        }
        if (transform.position.x > 7.7F)
        {
            Destroy();
            return;
        }
        transform.Rotate(new Vector3(0, 0, -15f));
    }

    private void OnTriggerEnter2D(Collider2D coll)
    {
        if (isHit) return;
        if (coll.tag == "Zombie")
        {
            isHit = true;
            // 播放僵尸被豌豆攻击的音效
            AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ZombieHurtForPea);

            // 让僵尸受伤
            coll.GetComponentInParent<ZombieBase>().Hurt(attackValue);
            // 修改成击中图片
            spriteRenderer.sprite = GameManager.Instance.GameConf.Bullet1Hit;

            // 暂停自身的运动
            rigidbody.velocity = Vector2.zero;

            // 下落
            rigidbody.gravityScale = 1;

            // 销毁自身
            Invoke("Destroy", 0.5f);

        }
        if (coll.tag == "TorchWood")
        {
            coll.GetComponentInParent<TorchWood>().Fire(attackValue);
            Destroy();
        }
    }

    private void Destroy()
    {
        // 取消延迟调用
        CancelInvoke();
        // 把自己放进缓存池
        PoolManager.Instance.PushObj(GameManager.Instance.GameConf.Bullet1, gameObject);
    }
}
