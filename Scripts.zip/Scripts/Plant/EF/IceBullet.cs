using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IceBullet : MonoBehaviour
{
    //��¼һ��ʼ��y����
    private float y;
    //�ж�ֱ��
    private bool CanDown;
    private bool CanUp;
    private Rigidbody2D rigidbody;
    private SpriteRenderer spriteRenderer;
    // ������
    private int attackValue;
    // �Ƿ����
    private bool isHit;
    //�ӵ�ֱ��
    public void Init(int attackValue, Vector2 pos)
    {

        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // �޸ĳ�����״̬��ͼƬ
        spriteRenderer.sprite = GameManager.Instance.GameConf.IceBulletNor;
    }
    //�ӵ���б�Ϸ���ֱ��
    public void Init2(int attackValue, Vector2 pos)
    {
        this.y = pos.y;
        CanDown = true;
        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        rigidbody.AddForce(Vector2.up * 150);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // �޸ĳ�����״̬��ͼƬ
        spriteRenderer.sprite = GameManager.Instance.GameConf.IceBulletNor;
    }
    //�ӵ���б�·���ֱ��
    public void Init3(int attackValue, Vector2 pos)
    {
        this.y = pos.y;
        CanUp = true;
        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        rigidbody.AddForce(Vector2.down * 150);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // �޸ĳ�����״̬��ͼƬ
        spriteRenderer.sprite = GameManager.Instance.GameConf.IceBulletNor;
    }
    void Update()
    {
        if (isHit) return;
        if (transform.position.y - y >= 1.50f && CanDown)
        {
            CanDown = false;
            rigidbody.AddForce(Vector2.down * 150);
        }
        if (transform.position.y - y <= -1.50f && CanUp)
        {
            CanUp = false;
            rigidbody.AddForce(Vector2.up * 150);
        }
        if (transform.position.x > 7.7F)
        {
            Destroy();
            return;
        }
      
    }

    private void OnTriggerEnter2D(Collider2D coll)
    {
        if (isHit) return;
        if (coll.tag == "Zombie")
        {
            isHit = true;
            // ���Ž�ʬ���㶹��������Ч
            AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ZombieHurtForPea);

            // �ý�ʬ����
            coll.GetComponentInParent<ZombieBase>().Hurt(attackValue);
            //�ý�ʬ�ٶȹ�������
            coll.GetComponentInParent<ZombieBase>().SlowDown();
            // �޸ĳɻ���ͼƬ
            spriteRenderer.sprite = GameManager.Instance.GameConf.IceBulletHit;

            // ��ͣ�������˶�
            rigidbody.velocity = Vector2.zero;

            // ����
            rigidbody.gravityScale = 1;

            // ��������
            Invoke("Destroy", 0.5f);

        }
        if (coll.tag == "TorchWood")
        {
            Destroy();
        }
    }

    private void Destroy()
    {
        // ȡ���ӳٵ���
        CancelInvoke();
        // ���Լ��Ž������
        PoolManager.Instance.PushObj(GameManager.Instance.GameConf.IceBullet, gameObject);
    }
}
