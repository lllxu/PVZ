using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShroomBullet : MonoBehaviour
{
    //��¼һ��ʼ��y����
    private float y;
    //�ж�ֱ��
    private bool CanDown;
    private bool CanUp;
    private Rigidbody2D rigidbody;
    private SpriteRenderer spriteRenderer;
    private Animator anim;
    // ������
    private int attackValue;
    // �Ƿ����
    private bool isHit;
    //�ӵ�ֱ��
    public void Init(int attackValue, Vector2 pos)
    {

        transform.position = pos;
        rigidbody = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidbody.AddForce(Vector2.right * 300);
        this.attackValue = attackValue;
        rigidbody.gravityScale = 0;
        isHit = false;
        // �޸ĳ�����״̬��ͼƬ
        spriteRenderer.sprite = GameManager.Instance.GameConf.ShroomBulletNor;
        anim = GetComponent<Animator>();
        anim.enabled = true;
        anim.speed = 1;
    }
    void Update()
    {
        if (isHit) return;
        if (transform.position.x > 7.7F)
        {
            Destroy();
            return;
        }

    }

    private void OnTriggerEnter2D(Collider2D coll)
    {
        if (isHit) return;
        if (coll.tag == "Zombie")
        {
            isHit = true;
            // ���Ž�ʬ���㶹��������Ч
            AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ZombieHurtForPea);

            // �ý�ʬ����
            coll.GetComponentInParent<ZombieBase>().Hurt(attackValue);
            anim.speed = 0;
            anim.enabled = false;
            // �޸ĳɻ���ͼƬ
            spriteRenderer.sprite = GameManager.Instance.GameConf.ShroomBulletHit;

            // ��ͣ�������˶�
            rigidbody.velocity = Vector2.zero;

            // ��������
            Invoke("Destroy", 0.1f);

        }
    }

    private void Destroy()
    {
        // ȡ���ӳٵ���
        CancelInvoke();
        // ���Լ��Ž������
        PoolManager.Instance.PushObj(GameManager.Instance.GameConf.ShroomBullet, gameObject);
    }
}
