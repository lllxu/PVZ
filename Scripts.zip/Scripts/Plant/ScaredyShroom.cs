﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ScaredyShroom : PlantBase
{
    public override float MaxHp
    {
        get
        {
            return 300;
        }
    }
    public int state = 1;

    private string animationName;

    //白天黑夜
    private bool night = true;

    protected override float attackCD => 1.4f;

    protected override Vector2 offset => new Vector2(0, 0.2f);

    protected override int attackValue => 20;

    // 是否可以攻击
    private bool canAttack;

    // 创建子弹的偏移量
    private Vector3 creatBulletOffsetPos = new Vector2(0.562f, -0.2F);

    protected override void OnInitForPlace()
    {
        if(night==true) canAttack = true;
        // 可能要攻击
        InvokeRepeating("Attack", 0, 0.2f);
    }

    /// <summary>
    /// 攻击方法-循环检测
    /// </summary>
    private void Attack()
    {
        if(night==false)
        {
            state = 3;
            Calanimator();
            return;
        }
        if (canAttack == false)    return;
        //周围半径1.5格有没有僵尸
        List<ZombieBase> zombies1 = ZombieManager.Instance.GetZombies((int)currGrid.Point.y, transform.position, 3f);
        if (zombies1.Count > 0)
        {
            state = 2;
            Calanimator();
            return;
        }

        state = 1;
        Calanimator();
        // 从僵尸管理器 获取一个离我最近的僵尸
        ZombieBase zombie = ZombieManager.Instance.GetZombieByLineMinDistance((int)currGrid.Point.y, transform.position);
        // 没有僵尸 跳出
        if (zombie == null) return;
        // 僵尸必须在草坪上 否则跳出
        if (zombie.CurrGrid.Point.x == 8 && Vector2.Distance(zombie.transform.position, zombie.CurrGrid.Position) > 1.5f) return;
        // 如果僵尸不在我的左边，也跳出
        if (zombie.transform.position.x < transform.position.x) return;


        // 从这里开始，都是可以正常攻击的
        // 在枪口实例化一个子弹
        ShroomBullet shroomBullet = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.ShroomBullet).GetComponent<ShroomBullet>();
        shroomBullet.transform.SetParent(transform);
        shroomBullet.Init(attackValue, transform.position + creatBulletOffsetPos);
        CDEnter();
        canAttack = false;
    }
    private void Calanimator()
    {
        //正常状态
        if (state == 1)
        {
            animationName = "ScaredyShroom_Idel";
        }
        //攻击状态
        else if (state == 2)
        {
            animationName = "ScaredyShroom_Cry";
        }
        //消化状态
        else
        {
            animationName = "ScaredyShroom_Sleep";
        }
        animator.Play(animationName);
    }
    /// <summary>
    /// 进入CD
    /// </summary>
    private void CDEnter()
    {
        StartCoroutine(CalCD());
    }
    /// <summary>
    /// 计算冷却时间
    /// </summary>
    IEnumerator CalCD()
    {

        yield return new WaitForSeconds(attackCD);
        canAttack = true;

    }
}
