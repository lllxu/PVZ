﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SplitPea : PlantBase
{
    public override float MaxHp
    {
        get
        {
            return 300;
        }
    }

    protected override float attackCD => 1.4f;

    protected override int attackValue => 20;

    // 是否可以攻击
    private bool canAttackL;
    private bool canAttackR;

    // 创建子弹的偏移量
    private Vector3 creatBulletOffsetPos= new Vector2(0.562f,0.386F);
    private Vector3 creatBulletOffsetPos1 = new Vector2(-0.562f, 0.386F);
    private Vector3 creatBulletOffsetPos2 = new Vector2(-1.562f, 0.386F);

    protected override void OnInitForPlace()
    {
        canAttackL = true;
        canAttackR = true;
        // 可能要攻击
        InvokeRepeating("Attack",0, 0.2f);
    }

    /// <summary>
    /// 攻击方法-循环检测
    /// </summary>
    private void Attack()
    {
        print(1);
        if (canAttackL == false && canAttackR == false) return;

        // 从僵尸管理器 获取一个离我最近的僵尸
        ZombieBase zombieR = ZombieManager.Instance.GetZombieByLineMinDistanceRight((int)currGrid.Point.y, transform.position);
        ZombieBase zombieL = ZombieManager.Instance.GetZombieByLineMinDistanceLeft((int)currGrid.Point.y, transform.position);
        // 没有僵尸 跳出
        if (zombieR == null && zombieL == null) return;
        // 僵尸必须在草坪上 否则跳出
        if (zombieL != null && zombieL.CurrGrid.Point.x == 8 && Vector2.Distance(zombieL.transform.position, zombieL.CurrGrid.Position) > 1.5f)
        {
            canAttackL = false;
            zombieL = null;
        }
        if (zombieR != null && zombieR.CurrGrid.Point.x == 8 && Vector2.Distance(zombieR.transform.position, zombieR.CurrGrid.Position) > 1.5f)
        {
            canAttackR = false;
            zombieR = null;
        }
        if (zombieL != null && transform.position.x - zombieL.transform.position.x > 0)
        {
            canAttackL = true;
        }
        if (zombieR != null && transform.position.x - zombieR.transform.position.x < 0)
        {
            canAttackR = true;
        }
        // 如果僵尸在右边
        if (zombieL!=null&& canAttackL==true)
        {
            Bullet bullet = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Bullet1).GetComponent<Bullet>();
            bullet.transform.SetParent(transform);
            bullet.Initleft(attackValue, transform.position + creatBulletOffsetPos1);
            Bullet bullet2 = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Bullet1).GetComponent<Bullet>();
            bullet2.transform.SetParent(transform);
            bullet2.Initleft(attackValue, transform.position + creatBulletOffsetPos2);
           
        }
        if(zombieR!=null && canAttackR == true)
        {
            Bullet bullet = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Bullet1).GetComponent<Bullet>();
            bullet.transform.SetParent(transform);
            bullet.Init(attackValue, transform.position + creatBulletOffsetPos);
            
            
        }

        CDEnter();
        canAttackR = false;
        canAttackL = false;
        // 从这里开始，都是可以正常攻击的
        // 在枪口实例化一个子弹


    }

    /// <summary>
    /// 进入CD
    /// </summary>
    private void CDEnter()
    {
        StartCoroutine(CalCD());
    }
    /// <summary>
    /// 计算冷却时间
    /// </summary>
    IEnumerator CalCD()
    {

        yield return new WaitForSeconds(attackCD);
        canAttackR = true;
        canAttackL = true;

    }
}
