﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Squash : PlantBase
{
    public override float MaxHp => 300;

    protected override int attackValue => 1800;
    private string animationName;
    //初始化状态
    private int state = 1;
    protected override void OnInitForPlace()
    {
        // 每秒检测有没有敌人被我攻击
        Calanimator();
        InvokeRepeating("CheckAttack", 0, 0.2f);

    }
    /// <summary>
    /// 检测攻击
    /// </summary>
    private void CheckAttack()
    {
        Calanimator();
        //判断前面附近有没有僵尸
        List<ZombieBase> zombies = ZombieManager.Instance.GetZombies((int)currGrid.Point.y, transform.position, 2.5f);
        if (zombies.Count == 0) return;
        state = 2;
        Calanimator();
        
        StartCoroutine(Calstate3(zombies));

    }

    IEnumerator Calstate3(List<ZombieBase> zombies)
    {

        yield return new WaitForSeconds(1f);
        zombies = ZombieManager.Instance.GetZombies((int)currGrid.Point.y, transform.position, 2.5f);
        for (int i = 0; i < zombies.Count; i++)
        {
            zombies[i].Hurt(attackValue);
        }
        state = 1;
        Dead();

    }
    private void Calanimator()
    {
        //攻击状态
        if (state == 2)
        {
            animationName = "Squash_Attack";
        }
        //正常状态
        else
        { 
            animationName = "Squash_Idel";
        }
        animator.Play(animationName);

    }
    
}
