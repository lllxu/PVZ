using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TenManNut : PlantBase
{
    public override float MaxHp =>8000;

    protected override float attackCD => 1;

    protected override int attackValue => 30;

    protected override void OnInitForPlace()
    {
        // ÿ������û�е��˱��ҹ���
        InvokeRepeating("CheckAttack", 0, attackCD);
    }
    /// <summary>
    /// ��⹥��
    /// </summary>
    private void CheckAttack()
    {
        // �ҵ����Ա��ҹ����ĵ��ˣ����Ҹ����˺�
        List<ZombieBase> zombies = ZombieManager.Instance.GetZombies((int)currGrid.Point.y, transform.position, 1.2f);
        if (zombies == null) return;
        for (int i = 0; i < zombies.Count; i++)
        {
            zombies[i].Hurt(attackValue);
        }
    }

    
}
