using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Threepeater : PlantBase
{
    public override float MaxHp
    {
        get
        {
            return 300;
        }
    }

    protected override float attackCD => 1.4f;

    protected override int attackValue => 40;

    // �Ƿ���Թ���
    private bool canAttack;

    // �����ӵ���ƫ����
    private Vector3 creatBulletOffsetPos = new Vector2(0.562f, 0.386F);
    private Vector3 GridOffsetPos = new Vector2(0, 1.63F);
    protected override void OnInitForPlace()
    {
        canAttack = true;
        // ����Ҫ����
        InvokeRepeating("Attack", 0, 0.2f);
    }

    /// <summary>
    /// ��������-ѭ�����
    /// </summary>
    private void Attack()
    {
        if (canAttack == false) return;
        int y =(int)currGrid.Point.y;
        // �ӽ�ʬ������ ��ȡһ����������Ľ�ʬ
        // ��ʬ�����ڲ�ƺ�� ��������

        // �����ʬ�����ҵ���ߣ�Ҳ����

        ZombieBase zombie1 = ZombieManager.Instance.GetZombieByLineMinDistance(y, transform.position);
        if (zombie1!=null&&(zombie1.CurrGrid.Point.x == 8 
            && (Vector2.Distance(zombie1.transform.position, zombie1.CurrGrid.Position) > 1.5f)
            || zombie1.transform.position.x < transform.position.x) )
                zombie1 = null;
        ZombieBase zombie2 = ZombieManager.Instance.GetZombieByLineMinDistance(y-1, transform.position + GridOffsetPos);
        if (zombie2 != null &&(zombie2.CurrGrid.Point.x == 8 
            && (Vector2.Distance(zombie2.transform.position, zombie2.CurrGrid.Position) > 1.5f)
            || zombie2.transform.position.x < transform.position.x)) zombie2 = null;
        ZombieBase zombie3 = ZombieManager.Instance.GetZombieByLineMinDistance(y+1, transform.position - GridOffsetPos);
        if (zombie3 != null && (zombie3.CurrGrid.Point.x == 8 
            && (Vector2.Distance(zombie3.transform.position, zombie3.CurrGrid.Position) > 1.5f)
            || zombie3.transform.position.x < transform.position.x)) zombie3 = null;
        // û�н�ʬ ����
        if (zombie1 == null&&zombie2 ==null &&zombie3==null) return;
        

        // �����￪ʼ�����ǿ�������������
        // ��ǹ��ʵ���������ӵ�
        //��ǰ����
        Bullet bullet = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Bullet1).GetComponent<Bullet>();
        bullet.transform.SetParent(transform);
        bullet.Init(attackValue, transform.position + creatBulletOffsetPos);
        //���Ϸ���
        Bullet bullet2 = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Bullet1).GetComponent<Bullet>();
        bullet2.transform.SetParent(transform);
        bullet2.Init2(attackValue, transform.position + creatBulletOffsetPos);
        //���·���
        Bullet bullet3 = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Bullet1).GetComponent<Bullet>();
        bullet3.transform.SetParent(transform);
        bullet3.Init3(attackValue, transform.position + creatBulletOffsetPos);
        CDEnter();
        canAttack = false;
    }

    /// <summary>
    /// ����CD
    /// </summary>
    private void CDEnter()
    {
        StartCoroutine(CalCD());
    }
    /// <summary>
    /// ������ȴʱ��
    /// </summary>
    IEnumerator CalCD()
    {

        yield return new WaitForSeconds(attackCD);
        canAttack = true;

    }
}
