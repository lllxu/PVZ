﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlantType
{ 
    // 太阳花
    SunFlower,
    // 豌豆射手
    Peashooter,
    // 坚果
    WallNut,
    // 地刺
    Spike,
    // 樱桃
    Cherry,
    //双发豌豆
    Repeater,
    //三发豌豆
    Threepeater,
    //寒冰豌豆
    SnowPea,
    //大嘴花
    Chomper,
    //倭瓜
    Squash,
    //超级大嘴花
    BigChomper,
    //火炬树桩
    TorchWood,
    //机枪射手
    GatlingShooter,
    //高坚果
    TallWallNut,
    //石地刺
    Spikerock,
    //双子太阳花
    TwinSunflower,
    //地刺坚果
    TenManNut,
    //阳光菇
    SunShroom,
        //胆小菇
    ScaredyShroom,
    //裂荚豌豆
    SplitPea
}
public class PlantManager : MonoBehaviour
{
    public static PlantManager Instance;
    private void Awake()
    {
        Instance = this;
    }

    public GameObject GetPlantByType(PlantType type)
    {
        switch (type)
        {
            case PlantType.SunFlower:
                return GameManager.Instance.GameConf.SunFlower;
            case PlantType.Peashooter:
                return GameManager.Instance.GameConf.Peashooter;
            case PlantType.WallNut:
                return GameManager.Instance.GameConf.WallNut;
            case PlantType.Spike:
                return GameManager.Instance.GameConf.Spike;
            case PlantType.Cherry:
                return GameManager.Instance.GameConf.Cherry;
            case PlantType.Repeater:
                return GameManager.Instance.GameConf.Repeater;
            case PlantType.Threepeater:
                return GameManager.Instance.GameConf.Threepeater;
            case PlantType.SnowPea:
                return GameManager.Instance.GameConf.SnowPea;
            case PlantType.Chomper:
                return GameManager.Instance.GameConf.Chomper;
            case PlantType.Squash:
                return GameManager.Instance.GameConf.Squash;
            case PlantType.BigChomper:
                return GameManager.Instance.GameConf.BigChomper;
            case PlantType.TorchWood:
                return GameManager.Instance.GameConf.TorchWood;
            case PlantType.GatlingShooter:
                return GameManager.Instance.GameConf.GatlingShooter;
            case PlantType.TallWallNut:
                return GameManager.Instance.GameConf.TallWallNut;
            case PlantType.Spikerock:
                return GameManager.Instance.GameConf.Spikerock;
            case PlantType.TwinSunflower:
                return GameManager.Instance.GameConf.TwinSunflower;
            case PlantType.TenManNut:
                return GameManager.Instance.GameConf.TenManNut;
            case PlantType.SunShroom:
                return GameManager.Instance.GameConf.SunShroom;
            case PlantType.ScaredyShroom:
                return GameManager.Instance.GameConf.ScaredyShroom;
            case PlantType.SplitPea:
                return GameManager.Instance.GameConf.SplitPea;
        }
        return null;
    }
}
