﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StartSceneManager : MonoBehaviour
{
    public static StartSceneManager Instance;
    public Slider slider;
    public int typeFlag;//11.21
    private SetPanel setpanel;
    private MakersPanel makerspanel;
    private HelpPanel helppanel;

    //是否自动拾取阳光
    public bool isAutoPickSun;
    //是否让铲子攻击僵尸
    public bool isShovelAttack;

    private void Awake()
    {
        Instance = this;
        setpanel = transform.Find("SetPanel").GetComponent<SetPanel>();
        setpanel.gameObject.SetActive(false);
        makerspanel = transform.Find("MakersPanel").GetComponent<MakersPanel>();
        makerspanel.gameObject.SetActive(false);
        helppanel = transform.Find("HelpPanel").GetComponent<HelpPanel>();
        helppanel.gameObject.SetActive(false);
        isAutoPickSun = false;
        isShovelAttack = false;
        typeFlag = 1;

}
    public void GoEndLess()
    {
        // 清理对象池
        PoolManager.Instance.Clear();
        // 播放音效
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ButtonClick);
        Invoke("DoGoEndLess", 0.5f);

    }
    private void DoGoEndLess()
    {
        typeFlag = 0;//11.21
        SceneManager.LoadScene("SelectLevel");
    }
    public void GoMiniGame()//11.21
    {
        // 清理对象池
        PoolManager.Instance.Clear();
        // 播放音效
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ButtonClick);
        Invoke("DoGoMiniGame", 0.5f);

    }
    private void DoGoMiniGame()//11.21
    {
        typeFlag = 1;//11.21
        SceneManager.LoadScene("Endless");
    }
    public void DogoBook()
    {
        SceneManager.LoadScene("Book");
    }
    public void Quit()
    {
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ButtonClick);
        Application.Quit();
    }
    public void Volume()
    {
        AudioListener.volume = slider.value;
    }
    public void ShowSetpanel()
    {
        setpanel.Show(true);
    }
    public void ShowMakersPanel()
    {
        makerspanel.Show(true);
    }
    public void ShowHelpPanel()
    {
        helppanel.Show(true);
    }
    public void AutoPickSun()
    {
        if (isAutoPickSun == false)
        {
            isAutoPickSun = true;
        }
        else
        {
            isAutoPickSun = false;
        }
    }
    public void ShovelAttack()
    {
        if (isShovelAttack == false)
        {
            isShovelAttack = true;
        }
        else
        {
            isShovelAttack = false;
        }
    }
}
