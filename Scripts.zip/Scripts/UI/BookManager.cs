using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class BookManager : MonoBehaviour
{

    public void DoGoPlant()
    {
        SceneManager.LoadScene("bookPlant");
    }
    public void DoGoStart()
    {
        SceneManager.LoadScene("Start");
    }
    public void DoGoZombie()
    {
        SceneManager.LoadScene("bookZombie");
    }
    public void DogoBook()
    {
        SceneManager.LoadScene("Book");
    }

}
