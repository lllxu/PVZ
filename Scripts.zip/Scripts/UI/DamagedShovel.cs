using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DamagedShovel : MonoBehaviour
{
    private DamagedShovel damagedShovel;
    public void Show(bool isShow)
    {
        gameObject.SetActive(isShow);
    }
}
