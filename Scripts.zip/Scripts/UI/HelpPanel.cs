using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HelpPanel : MonoBehaviour
{
    private HelpPanel helppanel;
    public void Show(bool isShow)
    {
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ButtonClick);
        gameObject.SetActive(isShow);
        // �����ʾ��������ζ����Ϸ��ͣ
        if (isShow)
        {
            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = 1;

        }

    }
}
