using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LawnCleaner : MonoBehaviour
{
    public static LawnCleaner Instance;
    private Transform lawnCleaner;

    private int attackVal = 999;

    private int speed = 10;

    public bool isRun;

    private void Awake()
    {
        Instance = this;
    }
    void Start()
    {
        isRun = false;
    }
    void Update()
    {
        if (!isRun && CheckWhetherZombieIsClose())
        {
            isRun = true;
        }
        if (isRun)
        {
            KillZombie();
            transform.Translate((new Vector2(1.33f, 0) * (Time.deltaTime / 1)) * speed);
        }
        if (transform.position.x >= 100)
            Destroy();
    }
    /// <summary>
    /// ɱ�����������ʬ
    /// </summary>
    private void KillZombie()
    {
        Vector3 LCPoint = transform.position;
        LCPoint.z = 0.0F;
        Vector2 pos = ZombieManager.Instance.GetZombieByLineMinPosOfMouse((int)LCPoint.y, LCPoint);
        ZombieBase zombie = ZombieManager.Instance.GetZombieByLineMinDistanceOfMouse((int)LCPoint.y, LCPoint);
        if (Vector2.Distance(LCPoint, pos) >= 0.5F)
        {
            return;
        }
        zombie.State = ZombieState.Dead;
    }
    /// <summary>
    /// ����Ƿ��н�ʬ�������ݻ�
    /// </summary>
    /// <returns></returns>
    private bool CheckWhetherZombieIsClose()
    {
        Vector3 LCPoint = transform.position;
        LCPoint.z = 0.0F;
        Vector2 pos = ZombieManager.Instance.GetZombieByLineMinPosOfMouse((int)LCPoint.y, LCPoint);
     //   Debug.Log(LCPoint);
    //    Debug.Log(pos);
     //   Debug.Log(Vector2.Distance(LCPoint, pos));
        if (Vector2.Distance(LCPoint, pos) >= 0.5F)
        {
            return false;
        }
        return true;
    }
    private void Destroy()
    {
           PoolManager.Instance.PushObj(GameManager.Instance.GameConf.LawnCleaner, gameObject);
    }
}
