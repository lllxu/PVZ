using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SelectAny : MonoBehaviour
{
    public void GetText()
    {
        string text = GameObject.Find("/Canvas/Select/S1").GetComponent<InputField>().text;
        int num= int.Parse(text);
        if (num < 1)
            return;
        SelectLevel.Instance.lv = num;
        SceneManager.LoadScene("EndLess");

    }

}