using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SelectLevel : MonoBehaviour
{
    public static SelectLevel Instance;
    public int lv;
    private void Awake()
    {
        Instance = this;
    }
    public void ReturnToHome()
    {
        SceneManager.LoadScene("Start");
    }

    public void Enter(int LV)
    {
        lv = LV;
        SceneManager.LoadScene("EndLess");
    }


}
