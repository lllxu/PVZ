﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Shovel : MonoBehaviour,IPointerClickHandler,IPointerEnterHandler,IPointerExitHandler
{
    public static Shovel Instance;
    private Transform shoveImg;
    // 是否在使用铲子中
    private bool isShove;

    //判断铲子是否是好的
    private bool isOK;

   
    public bool IsShove 
    {
        get { return isShove; }
        set {
            isShove = value;
            // 需要铲植物
            if (isShove)
            {
                AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.Shovel);
                shoveImg.localRotation = Quaternion.Euler(0, 0, 45);

            }
            // 把铲子放回去
            else
            {
                AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.Shovel);
                shoveImg.localRotation = Quaternion.Euler(0, 0, 0);
                shoveImg.transform.position = transform.position;
            }           
        }
    }
    public bool IsOK
    {
        get { return isOK; }
        set
        {
            isOK = value;
            // 需要铲植物
            if (!isOK)
            {
                IsShove = false;
                shoveImg = transform.Find("DamagedShovel");
                shoveImg.transform.position = transform.position;
           //     UnityEngine.Debug.Log(isOK);
            }
        }
    }
    private void Awake()
    {
        Instance = this;
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        
        if (IsShove==false)
        {
            if (!IsOK)
            {
                return;
            }
            IsShove = true;
        }
        else
        {
            IsShove = false;
        }
                
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if(IsOK)
          shoveImg.transform.localScale = new Vector2(1.4f, 1.4f);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (IsOK)
            shoveImg.transform.localScale = new Vector2(1f, 1f);
    }

    void Start()
    {

        shoveImg = transform.Find("Image");
        LVManager.Instance.AddLVStartActionLinstener(OnLVStartAction);
        IsOK = true;
    }

    void Update()
    {
        // 如果需要铲植物
        if (!IsOK)
            return;
        if (IsShove)
        {
            shoveImg.position = Input.mousePosition;

            // 点击左键，判断是否要铲除植物
            if (Input.GetMouseButtonDown(0))
            {
                Grid grid= GridManager.Instance.GetGridByMouse();
                if ((StartSceneManager.Instance.isShovelAttack ||UIManager.Instance.isShovelAttack)&& KillZombie())
                {
                    IsOK = false;
                    return;
                }
                // 如果没有植物，取消铲子状态
                if (grid.CurrPlantBase == null)
                {
                    IsShove = false;
                    return;
                }
                // 如果鼠标距离网格的距离小于1.5米，则杀死这个植物
                if (Vector2.Distance(Camera.main.ScreenToWorldPoint(Input.mousePosition),grid.CurrPlantBase.transform.position)<1.5f)
                {
                    grid.CurrPlantBase.Dead();
                    IsShove = false;
                }                        
            }

            
        }
                    
    }

    private void OnLVStartAction()
    {
        IsShove = false;
    }
    /// <summary>
    /// 杀死最近僵尸
    /// </summary>
    /// <returns></returns>
    private bool KillZombie()
    {
        Vector3 mousePoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Vector2 pos = ZombieManager.Instance.GetZombieByLineMinPosOfMouse((int)mousePoint.y, mousePoint);
        ZombieBase zombie = ZombieManager.Instance.GetZombieByLineMinDistanceOfMouse((int)mousePoint.y, mousePoint);
        if (Vector2.Distance(mousePoint, pos) >= 1.5F)
        {
            return false;
        }
        zombie.State = ZombieState.Dead;
      //  shoveImg = transform.Find("DamagedShovel");
        return true;
    }
}