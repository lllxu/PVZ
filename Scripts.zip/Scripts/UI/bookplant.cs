using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
public class bookplant : MonoBehaviour
{
    public static bookplant Instance;
    private Transform P1;
    private bool[] isShow = new bool[100];
    private void Start()
    {
        P1 = transform.Find("plantImage/P (1)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (2)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (3)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (4)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (5)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (6)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (7)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (8)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (9)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (10)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (11)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (12)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (13)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (14)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (15)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (16)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (17)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (18)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (19)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (20)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (21)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (22)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (23)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (24)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (25)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (26)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (27)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (28)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (29)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (30)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (31)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (32)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (33)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (34)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (35)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (36)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (37)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (38)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (39)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (40)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (41)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (42)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (43)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (44)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("plantImage/P (45)");
        P1.gameObject.SetActive(false);

        for (int i = 0; i <= 50; i++)
        {
            isShow[i] = false;
        }
    }
    public void show(int id)
    {
        P1 = transform.Find("plantImage/P (" + id + ")");
        P1.gameObject.SetActive(isShow[id]);
    }
    public void closeOthers()
    {
        for (int i = 0; i <= 50; i++)
        {
            if (isShow[i] == true)
            {
                isShow[i] = false;
                show(i);
            }
        }
    }
    public void change(int nowPos)
    {
        if (isShow[nowPos] == false)
        {
            closeOthers();
            isShow[nowPos] = true;
        }
        else
        {
            isShow[nowPos] = false;
        }
        show(nowPos);
    }



}
