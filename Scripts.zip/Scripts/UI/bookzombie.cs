using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
public class bookzombie : MonoBehaviour
{
    public static bookzombie Instance;
    private Transform P1;
    private bool[] isShow = new bool[100];
    private void Start()
    {
        P1 = transform.Find("zombieImage/P (1)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (2)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (3)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (4)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (5)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (6)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (7)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (8)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (9)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (10)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (11)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (12)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (13)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (14)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (15)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (16)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (17)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (18)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (19)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (20)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (21)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (22)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (23)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (24)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (25)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (26)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (27)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (28)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (29)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (30)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (31)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (32)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (33)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (34)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (35)");
        P1.gameObject.SetActive(false);
        P1 = transform.Find("zombieImage/P (36)");
        P1.gameObject.SetActive(false);

        for (int i = 0; i <= 50; i++)
        {
            isShow[i] = false;
        }
    }
    public void show(int id)
    {
        P1 = transform.Find("zombieImage/P (" + id + ")");
        P1.gameObject.SetActive(isShow[id]);
    }
    public void closeOthers()
    {
        for (int i = 0; i <= 50; i++)
        {
            if (isShow[i] == true)
            {
                isShow[i] = false;
                show(i);
            }
        }
    }
    public void change(int nowPos)
    {
        if (isShow[nowPos] == false)
        {
            closeOthers();
            isShow[nowPos] = true;
        }
        else
        {
            isShow[nowPos] = false;
        }
        show(nowPos);
    }



}
