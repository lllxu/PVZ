using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WelcomeSceneManager : MonoBehaviour

{

    public void GoStart()
    {
        // ���������
        PoolManager.Instance.Clear();
        // ������Ч
        //AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ButtonClick);
        Invoke("DoGoStart", 0.5f);

    }

    private void DoGoStart()
    {
        SceneManager.LoadScene("Start");
    }
    
}
