using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class CX : ZombieBase
{

    protected override int MaxHP => 2500;

    protected override float speed => 10;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.Zombie;



    public override void InitZombieHpState()
    {
        
        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 50 },
            new List<string>() { "Zombie_Walk1", "Zombie_LostHead" },
            new List<string>() { "Zombie_Attack", "Zombie_LostHeadAttack" },
            new List<UnityAction>() { null, CheckLostHead }
            );
    }

    public override void OnDead()
    {
        // ����һ����������
        Zombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.CXZombie_DieBody).GetComponent<Zombie_DieBody>();
        body.Init(animator.transform.position);
    }

    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            Zombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.CXZombie_Head).GetComponent<Zombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }

    /// <summary>
    /// ��������ʬ�����ʼ��
    /// </summary>
    public void InitForOhterZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "Zombie_Walk1";
        animator.Play("Zombie_Walk1", 0, time);
    }
}
