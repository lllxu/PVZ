using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Emperor : ZombieBase
{
    protected override int MaxHP => 5000;

    protected override float speed => 15;

    protected override float attackValue => 300;

    protected override GameObject Prefab => GameManager.Instance.GameConf.Emperor;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState
           (
           0,
           new List<int>() { MaxHP, 270},
           new List<string>() { "Emperor_Walk", "Emperor_Walk",  },
           new List<string>() { "Emperor_Attack", "Emperor_Attack" },
           new List<UnityAction>() { null,null}
           );
    }

    public override void OnDead()
    {
        Emperor_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Emperor_DieBody).GetComponent<Emperor_DieBody>();
        body.Init(animator.transform.position);
    }
    public void HpStateEvent()
    {

        // ��������
        State = ZombieState.Dead;
    }
}
