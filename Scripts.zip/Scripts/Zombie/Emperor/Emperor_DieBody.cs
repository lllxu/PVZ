using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Emperor_DieBody : BaseEFObj
{
    public override string AnimationName => "Emperor_Die";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.Emperor_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}
