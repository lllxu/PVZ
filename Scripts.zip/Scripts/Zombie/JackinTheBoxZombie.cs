using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class JackinTheBoxZombie : ZombieBase
{
    protected override int MaxHP => 500;

    protected override float speed => 2.2f;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.JackinTheBoxZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
             0,
             new List<int>() { MaxHP, 50 },
             new List<string>() { "JackinTheBoxZombie_Walk", "JackinTheBoxZombie_LostHeadWalk" },
             new List<string>() { "JackinTheBoxZombie_Attack", "JackinTheBoxZombie_LostHeadAttack", "JackinTheBoxZombie_Open", "JackinTheBoxZombie_Boom" },
             new List<UnityAction>() { null, CheckLostHead },
             false,
             true
             );
    }

    public override void OnDead()
    {
        // ����һ����������
        JackinTheBoxZombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.JackinTheBoxZombie_DieBody).GetComponent<JackinTheBoxZombie_DieBody>();
        body.Init(animator.transform.position);
    }
    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            JackinTheBoxZombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.JackinTheBoxZombie_Head).GetComponent<JackinTheBoxZombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }
    public void InitForOhterJackinTheBoxZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "JackinTheBoxZombie_Walk";
        animator.Play("JackinTheBoxZombie_Walk", 0, time);
    }   
}
