using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JackinTheBoxZombie_DieBody : BaseEFObj
{
    public override string AnimationName => "JackinTheBoxZombie_DieBody";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.JackinTheBoxZombie_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}
