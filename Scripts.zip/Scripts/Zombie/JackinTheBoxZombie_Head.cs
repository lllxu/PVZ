using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JackinTheBoxZombie_Head : BaseEFObj
{
    public override string AnimationName => "JackinTheBoxZombie_Head";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.JackinTheBoxZombie_Head;
}
