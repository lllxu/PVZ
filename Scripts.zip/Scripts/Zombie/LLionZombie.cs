using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class LLionZombie : ZombieBase
{
    protected override int MaxHP =>1100;

    protected override float speed => 5;

    protected override float attackValue => 200;

    protected override GameObject Prefab => GameManager.Instance.GameConf.LLionZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 370 },
            new List<string>() { "LLionZombie_Walk" },
            new List<string>() { "LLionZombie_Attack" },
            new List<UnityAction>() { null, HpStateEvent }
         );
    }

    public override void OnDead()
    {
    }

    /// <summary>   
    /// ����ֵ����ʱ����һ����ͨ��ʬ
    /// </summary>
    public void HpStateEvent()
    {
        // ���ٻ�һ����ͨ��ʬ
        LionDanceZombie zombie = ZombieManager.Instance.CreatStandLionDanceZombie((int)currGrid.Point.y, transform.position);
        // ͬ������
        zombie.InitForOhterLionDanceZombieCreat(animator.GetCurrentAnimatorStateInfo(0).normalizedTime);

        // ��������-���漰��������ֱ����ʧ
        State = ZombieState.Dead;

    }
}
