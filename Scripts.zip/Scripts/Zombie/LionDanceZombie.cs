using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class LionDanceZombie : ZombieBase
{
    protected override int MaxHP => 370;

    protected override float speed => 6;

    protected override float attackValue =>100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.LionDanceZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
             0,
             new List<int>() { MaxHP, 50 },
             new List<string>() { "LionDanceZombie_Walk", "LionDanceZombie_LostHeadWalk" },
             new List<string>() { "LionDanceZombie_Attack", "LionDanceZombie_LostHeadAttack" },
             new List<UnityAction>() { null, CheckLostHead }
             );
    }

    public override void OnDead()
    {
        // ����һ����������
        LionDanceZombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.LionDanceZombie_DieBody).GetComponent<LionDanceZombie_DieBody>();
        body.Init(animator.transform.position);
    }
    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            Zombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Zombie_Head).GetComponent<Zombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }
    public void InitForOhterLionDanceZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "LionDanceZombie_Walk";
        animator.Play("LionDanceZombie_Walk", 0, time);
    }
}
