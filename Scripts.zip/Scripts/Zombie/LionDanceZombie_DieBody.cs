using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LionDanceZombie_DieBody : BaseEFObj
{
    public override string AnimationName => "LionDanceZombie_DieBody";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.LionDanceZombie_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}
