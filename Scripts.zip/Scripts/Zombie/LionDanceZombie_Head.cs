using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LionDanceZombie_Head : BaseEFObj
{
    public override string AnimationName => "LionDanceZombie";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.LionDanceZombie;
}

