using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class MustacheZombie : ZombieBase
{
    protected override int MaxHP =>810;

    protected override float speed => 6;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.MustacheZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
         0,
          new List<int>() { MaxHP, 50 },
         new List<string>() { "MustacheZombie_Walk" },
         new List<string>() { "MustacheZombie_Attack" },
         new List<UnityAction>() { null, HpStateEvent }
        );
    }

    public override void OnDead()
    {
    }

    /// <summary>   
    /// ����ֵ����ʱ����һ����ͨ��ʬ
    /// </summary>
    public void HpStateEvent()
    {
        // ���ٻ�һ����ͨ��ʬ
        Zombie zombie = ZombieManager.Instance.CreatStandZombie((int)currGrid.Point.y, transform.position);
        // ͬ������
        zombie.InitForOhterZombieCreat(animator.GetCurrentAnimatorStateInfo(0).normalizedTime);

        // ��������-���漰��������ֱ����ʧ
        State = ZombieState.Dead;

    }
}
