using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class NewspaperZombie :ZombieBase
{
    protected override int MaxHP => 270;

    protected override float speed => 1.8f;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.NewspaperZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
             0,
             new List<int>() { MaxHP, 50 },
             new List<string>() { "NewspaperZombie_Walk", "NewspaperZombie_LostHeadWalk" },
             new List<string>() { "NewspaperZombie_Attack", "NewspaperZombie_LostHeadAttack" },
             new List<UnityAction>() { null, CheckLostHead }
             );
    }

    public override void OnDead()
    {
        // ����һ����������
        NewspaperZombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.NewspaperZombie_DieBody).GetComponent<NewspaperZombie_DieBody>();
        body.Init(animator.transform.position);
    }
    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            NewspaperZombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.NewspaperZombie_Head).GetComponent<NewspaperZombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }
    public void InitForOhterNewspaperZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "NewspaperZombie_Walk";
        animator.Play("NewspaperZombie_Walk", 0, time);
    }
}
