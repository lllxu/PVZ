using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewspaperZombie_DieBody : BaseEFObj
{
    public override string AnimationName => "NewspaperZombie_DieBody";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.NewspaperZombie_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}