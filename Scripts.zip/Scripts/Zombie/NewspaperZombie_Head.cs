using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewspaperZombie_Head : BaseEFObj
{
    public override string AnimationName => "NewspaperZombie_Head";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.NewspaperZombie_Head;
}
