using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class PPoleVaultingZombie : ZombieBase
{
    protected override int MaxHP => 500;

    protected override float speed => 2.5f;

    protected override float attackValue => 0;

    protected override GameObject Prefab => GameManager.Instance.GameConf.PPoleVaultingZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
               0,
               new List<int>() { MaxHP, 50 },
               new List<string>() { "PPoleVaultingZombie_Walk" },
               new List<string>() { "PPoleVaultingZombie_Jump", "PPoleVaultingZombie_Down" },
               new List<UnityAction>() { null, CheckLostHead },
               true
               );
    }

    public override void OnDead()
    {
        // ����һ����������
        PoleVaultingZombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.PoleVaultingZombie_DieBody).GetComponent<PoleVaultingZombie_DieBody>();
        body.Init(animator.transform.position);
    }
    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            PoleVaultingZombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.PoleVaultingZombie_Head).GetComponent<PoleVaultingZombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }
    public void InitForOhterPoleVaultingZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "PPoleVaultingZombie_Walk";
        animator.Play("PPoleVaultingZombie_Walk", 0, time);
    }






}
