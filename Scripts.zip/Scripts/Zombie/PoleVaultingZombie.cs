using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class PoleVaultingZombie :ZombieBase
{
    protected override int MaxHP =>500;

    protected override float speed =>6;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.PoleVaultingZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
             0,
             new List<int>() { MaxHP, 50 },
             new List<string>() { "PoleVaultingZombie_Walk", "PoleVaultingZombie_LostHeadWalk" },
             new List<string>() { "PoleVaultingZombie_Attack", "PoleVaultingZombie_LostHeadAttack" },
             new List<UnityAction>() { null, CheckLostHead }
             );
    }

    public override void OnDead()
    {
        // ����һ����������
        PoleVaultingZombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.PoleVaultingZombie_DieBody).GetComponent<PoleVaultingZombie_DieBody>();
        body.Init(animator.transform.position);
    }
    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            PoleVaultingZombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.PoleVaultingZombie_Head).GetComponent<PoleVaultingZombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }
    public void InitForOhterPoleVaultingZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "PoleVaultingZombie_Walk";
        animator.Play("PoleVaultingZombie_Walk", 0, time);
    }
}
