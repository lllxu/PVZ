using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoleVaultingZombie_DieBody : BaseEFObj
{
    public override string AnimationName => "PoleVaultingZombie_DieBody";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.PoleVaultingZombie_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}
