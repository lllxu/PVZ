using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoleVaultingZombie_Head : BaseEFObj
{
    public override string AnimationName => " PoleVaultingZombie_Head";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.PoleVaultingZombie_Head;
}
