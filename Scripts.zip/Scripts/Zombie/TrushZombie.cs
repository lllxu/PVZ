using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class TrushZombie : ZombieBase
{
    protected override int MaxHP => 1370;

    protected override float speed => 6;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.TrushZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 50 },
            new List<string>() { "TrushZombie_Walk" },
            new List<string>() { "TrushZombie_Attack" },
            new List<UnityAction>() { null, HpStateEvent }
         );
    }

    public override void OnDead()
    {

    }

    public void HpStateEvent()
    {
        // ���ٻ�һ����ͨ��ʬ
        Zombie zombie = ZombieManager.Instance.CreatStandZombie((int)currGrid.Point.y, transform.position);
        // ͬ������
        zombie.InitForOhterZombieCreat(animator.GetCurrentAnimatorStateInfo(0).normalizedTime);

        // ��������-���漰��������ֱ����ʧ
        State = ZombieState.Dead;

    }
}
