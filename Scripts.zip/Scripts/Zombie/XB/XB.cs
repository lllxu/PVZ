using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class XB : ZombieBase
{
    protected override int MaxHP => 450;

    protected override float speed => 6;
    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.XB;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 50 },
            new List<string>() { "XB_Walk", "XB_LostHead_Body" },
            new List<string>() { "XB_Attack", "XB_LostHeadAttack" },
            new List<UnityAction>() { null, CheckLostHead }
            );
    }

    public override void OnDead()
    {
        // ����һ����������
        XB_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.XB_DieBody).GetComponent<XB_DieBody>();
        body.Init(animator.transform.position);
    }

    // Start is called before the first frame update
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            XB_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.XB_Head).GetComponent<XB_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }

    public void InitForOhteroCZombieCreat(float time)
    {
        // �����߶���ȷ����walk
        zombieHpState.hpLimitWalkAnimationStr[0] = "XB_Walk";
        animator.Play("XB_Walk", 0, time);
    }
}
