using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XB_DieBody : BaseEFObj
{
    public override string AnimationName => "XB_DieBody";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.XB_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}
