using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XB_Head : BaseEFObj
{
    public override string AnimationName => "XB_Head";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.XB_Head;
}
