using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class Comboni_2 : ZombieBase
{

    protected override int MaxHP => 1350;

    protected override float speed => 8;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.Comboni_2;



    public override void InitZombieHpState()
    {

        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 270 },
            new List<string>() { "Zombie_Walk1", "Zombie_Walk2",  },
            new List<string>() { "Zombie_Attack", "Zombie_Attack" },
            new List<UnityAction>() { null, null }
            );
    }

    public override void OnDead()
    {
        // ����һ����������
        Zombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.ComboniZombie2_DieBody).GetComponent<Zombie_DieBody>();
        body.Init(animator.transform.position);
    }


}

