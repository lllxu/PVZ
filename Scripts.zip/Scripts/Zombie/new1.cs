using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class new1 : ZombieBase
{
    protected override int MaxHP => 1670;

    protected override float speed => 2.5f;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.New1;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 270,50},
            new List<string>() { "Zombie_walk", "Zombie_lostheadwalk", "Zombie_lostorwalk" },
            new List<string>() { "Zombie_Attack", "Zombie_lostheadortack", "Zombie_lostheadattack" },
            new List<UnityAction>() { null,  null , null }
            );
    }
   

    public void HpStateEvent()
    {
        
        // ��������-���漰��������ֱ����ʧ
        State = ZombieState.Dead;

    }
    public override void OnDead()
    {
        Zombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.Zombie_DieBodynew1).GetComponent<Zombie_DieBody>();
        body.Init(animator.transform.position);
    }
}
