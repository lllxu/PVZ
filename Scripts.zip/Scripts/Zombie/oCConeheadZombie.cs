using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class oCConeheadZombie : ZombieBase
{
    protected override int MaxHP => 450;

    protected override float speed => 6;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.oCConeheadZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
            0,
            new List<int>() { MaxHP, 270 },
            new List<string>() { "oCConeheadZombie_Walk", },
            new List<string>() { "oCConeheadZombie_Attack" },
            new List<UnityAction>() { null, HpStateEvent }
            );
    }

    public override void OnDead()
    {
    }
    /// <summary>   
    /// ����ֵ����ʱ����һ����ͨ��ʬ
    /// </summary>
    public void HpStateEvent()
    {
        // ���ٻ�һ����ͨ��ʬ
        oCZombie zombie = ZombieManager.Instance.CreatStandoCZombie((int)currGrid.Point.y, transform.position);
        // ͬ������
        zombie.InitForOhteroCZombieCreat(animator.GetCurrentAnimatorStateInfo(0).normalizedTime);

        // ��������-���漰��������ֱ����ʧ
        State = ZombieState.Dead;

    }
}
