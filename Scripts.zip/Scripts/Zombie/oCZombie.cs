using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class oCZombie : ZombieBase
{
    protected override int MaxHP => 270;

    protected override float speed => 6;

    protected override float attackValue => 100;

    protected override GameObject Prefab => GameManager.Instance.GameConf.oCZombie;

    public override void InitZombieHpState()
    {
        zombieHpState = new ZombieHpState(
             0,
             new List<int>() { MaxHP, 50 },
             new List<string>() { "oCZombie_Walk", "oCZombie_LostHeadWalk" },
             new List<string>() { "oCZombie_Attack", "oCZombie_LostHeadAttack" },
             new List<UnityAction>() { null, CheckLostHead }
             );
    }

    public override void OnDead()
    {
        // ����һ����������
        oCZombie_DieBody body = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.oCZombie_DieBody).GetComponent<oCZombie_DieBody>();
        body.Init(animator.transform.position);
    }
    /// <summary>
    /// ����ͷ
    /// </summary>
    private void CheckLostHead()
    {
        if (!isLostHead)
        {
            // ͷ��Ҫʧȥ
            isLostHead = true;
            // ����һ��ͷ
            oCZombie_Head head = PoolManager.Instance.GetObj(GameManager.Instance.GameConf.oCZombie_Head).GetComponent<oCZombie_Head>();
            head.Init(animator.transform.position);
            // ״̬���
            CheckState();
        }
    }
    public void InitForOhteroCZombieCreat(float time)
    {
        // �����߶���ȷ����walk3
        zombieHpState.hpLimitWalkAnimationStr[0] = "oCZombie_Walk";
        animator.Play("oCZombie_Walk", 0, time);
    }
}
