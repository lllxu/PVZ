using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class oCZombie_DieBody : BaseEFObj
{
    public override string AnimationName => "oCZombie_DieBody";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.oCZombie_DieBody;

    /// <summary>
    /// ����ը��ʱ�ĳ�ʼ��
    /// </summary>
    public void InitForBoomDie(Vector2 pos)
    {
        Init(pos, "Zombie_BoomDie");
    }
}
