using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class oCZombie_Head : BaseEFObj
{
    public override string AnimationName => "oCZombie_Head";
    public override GameObject PrefabForObjPool => GameManager.Instance.GameConf.oCZombie_Head;
}
