﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public enum ZombieType
{
    Zombie,
    FlagZombie,//旗帜
    ConeheadZombie,//路障
    BucketheadZombie,//铁桶
    oCBucketheadZombie,//桶
    oCConeheadZombie,//草帽
    oCZombie,//庶民
    MustacheZombie,//胡子
    LionDanceZombie,//舞狮1
    LLionZombie,//舞狮2
    NewspaperZombie,//没报纸
    NNewspaperZombie,//报纸
    PoleVaultingZombie,//撑杆跳没杆子
    PPoleVaultingZombie,//撑杆跳
    New1,//冰球
    football_2,//兵
    CX,//？
    Comboni,//车
    Comboni_2,//木马
    Emperor,//帝王
    XB,//断头
    TrushZombie,//垃圾桶
    JackinTheBoxZombie
}
public class ZombieManager : MonoBehaviour
{
    public static ZombieManager Instance;
    private List<ZombieBase> zombies= new List<ZombieBase>();
    private int currOrderNum = 0;

    // 创建僵尸最大和最小的X坐标
    private float creatMaxX=8.5f;
    private float creatMinX=7.4f;
    // 所有僵尸都死亡时的事件
    private UnityAction AllZombieDeadAction;
    public int CurrOrderNum { get => currOrderNum;
        set {
            currOrderNum = value;
            if (value>50)
            {
                currOrderNum = 0;
            }
        }
    
    }

    private void Awake()
    {
        Instance = this;
    }
    private void Start()
    {
        Groan();
    }
    /// <summary>
    /// 更新僵尸
    /// </summary>
    /// <param name="zombieNum"></param>
    public void UpdateZombie(int zombieNum,ZombieType zombieType)
    {
        for (int i = 0; i < zombieNum; i++)
        {
            CretaZombie(Random.Range(0,5), zombieType);
        }
        
    }

    /// <summary>
    /// 清理掉所有僵尸
    /// </summary>
    public void ClearZombie()
    {
        while (zombies.Count>0)
        {
            zombies[0].Dead(false);
        }

    }

    /// <summary>
    /// 获取一个X随机坐标，为了创建僵尸
    /// </summary>
    private float GetPosXRangeForCreatZombie()
    {
        return Random.Range(creatMinX,creatMaxX);
    }

    /// <summary>
    /// 创建一个普通僵尸
    /// </summary>
    public Zombie CreatStandZombie(int lineNum,Vector2 pos)
    {
        GameObject prefab = GameManager.Instance.GameConf.Zombie;
        Zombie zombie = PoolManager.Instance.GetObj(prefab).GetComponent<Zombie>();
        AddZombie(zombie);
        zombie.transform.SetParent(transform);
        zombie.Init(lineNum, CurrOrderNum, pos);
        CurrOrderNum++;
        return zombie;
    }

    /// <summary>
    /// 创建一个庶民僵尸
    /// </summary>
    public oCZombie CreatStandoCZombie(int lineNum, Vector2 pos)
    {
        GameObject prefab = GameManager.Instance.GameConf.oCZombie;
        oCZombie zombie = PoolManager.Instance.GetObj(prefab).GetComponent<oCZombie>();
        AddZombie(zombie);
        zombie.transform.SetParent(transform);
        zombie.Init(lineNum, CurrOrderNum, pos);
        CurrOrderNum++;
        return zombie;
    }

    /// <summary>
    /// 创建一个舞狮僵尸
    /// </summary>
    public LionDanceZombie CreatStandLionDanceZombie(int lineNum, Vector2 pos)
    {
        GameObject prefab = GameManager.Instance.GameConf.LionDanceZombie;
        LionDanceZombie zombie = PoolManager.Instance.GetObj(prefab).GetComponent<LionDanceZombie>();
        AddZombie(zombie);
        zombie.transform.SetParent(transform);
        zombie.Init(lineNum, CurrOrderNum, pos);
        CurrOrderNum++;
        return zombie;
    }

    /// <summary>
    /// 创建一个读报僵尸
    /// </summary>
    public NewspaperZombie CreatStandNewspaperZombie(int lineNum, Vector2 pos)
    {
        GameObject prefab = GameManager.Instance.GameConf.NewspaperZombie;
        NewspaperZombie zombie = PoolManager.Instance.GetObj(prefab).GetComponent<NewspaperZombie>();
        AddZombie(zombie);
        zombie.transform.SetParent(transform);
        zombie.Init(lineNum, CurrOrderNum, pos);
        CurrOrderNum++;
        return zombie;
    }

    /// <summary>
    /// 创建一个撑杆跳僵尸
    /// </summary>
    public PoleVaultingZombie CreatStandPoleVaultingZombie(int lineNum, Vector2 pos)
    {
        GameObject prefab = GameManager.Instance.GameConf.PoleVaultingZombie;
        PoleVaultingZombie zombie = PoolManager.Instance.GetObj(prefab).GetComponent<PoleVaultingZombie>();
        AddZombie(zombie);
        zombie.transform.SetParent(transform);
        zombie.Init(lineNum, CurrOrderNum, pos);
        CurrOrderNum++;
        return zombie;
    }

    /// <summary>
    /// 创建僵尸
    /// </summary>
    private void CretaZombie(int lineNum, ZombieType zombieType)
    {
        GameObject prefab = null;
        switch (zombieType)
        {
            case ZombieType.Zombie:
                prefab = GameManager.Instance.GameConf.Zombie;
                break;
            case ZombieType.FlagZombie:
                prefab = GameManager.Instance.GameConf.FlagZombie;
                break;
            case ZombieType.ConeheadZombie:
                prefab = GameManager.Instance.GameConf.ConeheadZombie;
                break;
            case ZombieType.BucketheadZombie:
                prefab = GameManager.Instance.GameConf.BucketheadZombie;
                break;
            case ZombieType.oCBucketheadZombie:
                prefab = GameManager.Instance.GameConf.oCBucketheadZombie;
                break;
            case ZombieType.oCConeheadZombie:
                prefab = GameManager.Instance.GameConf.oCConeheadZombie;
                break;
            case ZombieType.oCZombie:
                prefab = GameManager.Instance.GameConf.oCZombie;
                break;
            case ZombieType.MustacheZombie:
                prefab = GameManager.Instance.GameConf.MustacheZombie;
                break;
            case ZombieType.LionDanceZombie:
                prefab = GameManager.Instance.GameConf.LionDanceZombie;
                break;
            case ZombieType.LLionZombie:
                prefab = GameManager.Instance.GameConf.LLionZombie;
                break;
            case ZombieType.NewspaperZombie:
                prefab = GameManager.Instance.GameConf.NewspaperZombie;
                break;
            case ZombieType.NNewspaperZombie:
                prefab = GameManager.Instance.GameConf.NNewspaperZombie;
                break;
            case ZombieType.PoleVaultingZombie:
                prefab = GameManager.Instance.GameConf.PoleVaultingZombie;
                break;
            case ZombieType.PPoleVaultingZombie:
                prefab = GameManager.Instance.GameConf.PPoleVaultingZombie;
                break;
            case ZombieType.New1:
                prefab = GameManager.Instance.GameConf.New1;
                break;
            case ZombieType.football_2:
                prefab = GameManager.Instance.GameConf.football_2;
                break;
            case ZombieType.CX:
                prefab = GameManager.Instance.GameConf.CX;
                break;
            case ZombieType.Comboni:
                prefab = GameManager.Instance.GameConf.Comboni;
                break;
            case ZombieType.Comboni_2:
                prefab = GameManager.Instance.GameConf.Comboni_2;
                break;
            case ZombieType.Emperor:
                prefab = GameManager.Instance.GameConf.Emperor;
                break;
            case ZombieType.XB:
                prefab = GameManager.Instance.GameConf.XB;
                break;
            case ZombieType.TrushZombie:
                prefab = GameManager.Instance.GameConf.TrushZombie;
                break;
            case ZombieType.JackinTheBoxZombie:
                prefab = GameManager.Instance.GameConf.JackinTheBoxZombie;
                break;
        }
        ZombieBase zombie = PoolManager.Instance.GetObj(prefab).GetComponent<ZombieBase>();
        AddZombie(zombie);
        zombie.transform.SetParent(transform);
        zombie.Init(lineNum, CurrOrderNum, new Vector2(GetPosXRangeForCreatZombie(), 0));
        CurrOrderNum++;
    }

    public void AddZombie(ZombieBase zombie)
    {
        zombies.Add(zombie);
    }
    public void RemoveZombie(ZombieBase zombie)
    {
        zombies.Remove(zombie);
        CheckAllZombieDeadForLV();
    }

    /// <summary>
    /// 获取一个距离植物最近的僵尸
    /// </summary>
    /// <returns></returns>
    public ZombieBase GetZombieByLineMinDistance(int lineNum,Vector3 pos)
    {
        ZombieBase zombie = null;
        float dis = 10000;
        for (int i = 0; i < zombies.Count; i++)
        {
            if (zombies[i].CurrGrid.Point.y ==lineNum
                &&Vector2.Distance(pos,zombies[i].transform.position)< dis)
            {
                dis = Vector2.Distance(pos, zombies[i].transform.position);
                zombie = zombies[i];
            }
        }
        return zombie;
    }
    /// <summary>
    /// 获取一个距离植物右边最近的僵尸
    /// </summary>
    /// <returns></returns>
    public ZombieBase GetZombieByLineMinDistanceRight(int lineNum, Vector3 pos)
    {
        ZombieBase zombie = null;
        float dis = 10000;
        for (int i = 0; i < zombies.Count; i++)
        {
            if (zombies[i].CurrGrid.Point.y == lineNum
                && Vector2.Distance(pos, zombies[i].transform.position) < dis && pos.x - zombies[i].CurrGrid.Point.x <= 0)
            {
                dis = Vector2.Distance(pos, zombies[i].transform.position);
                zombie = zombies[i];
            }
        }
        return zombie;
    }
    /// <summary>
    /// 获取一个距离植物左边最近的僵尸
    /// </summary>
    /// <returns></returns>
    public ZombieBase GetZombieByLineMinDistanceLeft(int lineNum, Vector3 pos)
    {
        ZombieBase zombie = null;
        float dis = 10000;
        for (int i = 0; i < zombies.Count; i++)
        {
            if (zombies[i].CurrGrid.Point.y == lineNum
                && Vector2.Distance(pos, zombies[i].transform.position) < dis && pos.x - zombies[i].CurrGrid.Point.x > 0)
            {
                dis = Vector2.Distance(pos, zombies[i].transform.position);
                zombie = zombies[i];
            }
        }
        return zombie;
    }
    /// <summary>
    /// 获取一个距离鼠标最近的僵尸
    /// </summary>
    /// <param name="lineNum"></param>
    /// <param name="pos"></param>
    /// <returns></returns>
    public ZombieBase GetZombieByLineMinDistanceOfMouse(int lineNum, Vector3 pos)
    {
        ZombieBase zombie = null;
        float dis = 10000;
        for (int i = 0; i < zombies.Count; i++)
        {
            if (Vector2.Distance(pos, zombies[i].transform.position) < dis)
            {
                dis = Vector2.Distance(pos, zombies[i].transform.position);
                zombie = zombies[i];
            }
        }
        return zombie;
    }
    /// <summary>
    /// 获取距离鼠标最近僵尸的坐标
    /// </summary>
    /// <param name="lineNum"></param>
    /// <param name="pos"></param>
    /// <returns></returns>
    public Vector2 GetZombieByLineMinPosOfMouse(int lineNum, Vector3 pos)
    {
        Vector2 zomiePos = new Vector2(0.0F,0.0F);
        float dis = 10000f;
        for (int i = 0; i < zombies.Count; i++)
        {
            if (Vector2.Distance(pos, zombies[i].transform.position) < dis)
            {
                dis = Vector2.Distance(pos, zombies[i].transform.position);
                zomiePos = zombies[i].transform.position;
            }
        }
        return zomiePos;
    }
    /// <summary>
    /// 获取 指定Y轴   X轴的距离指定目标 小于 指定距离的僵尸们
    /// </summary>
    public List<ZombieBase> GetZombies(int lineNum, Vector2 targetPos, float dis)
    {
        List<ZombieBase> temps = new List<ZombieBase>();

        
        for (int i = 0; i < zombies.Count; i++)
        {
            if (zombies[i].CurrGrid.Point.y == lineNum
                &&Vector2.Distance(new Vector2(targetPos.x, 0), new Vector2(zombies[i].transform.position.x+0.52f,0))<dis)
            {
                temps.Add(zombies[i]);
            }
        }
        return temps;
    }

    /// <summary>
    /// 获取距离目标指定范围内的全部僵尸
    /// </summary>
    /// <returns></returns>
    public List<ZombieBase> GetZombies(Vector2 targetPos,float dis)
    {
        List<ZombieBase> temps = new List<ZombieBase>();
        for (int i = 0; i < zombies.Count; i++)
        {
            if (Vector2.Distance(targetPos, zombies[i].transform.position) < dis)
            {
                temps.Add(zombies[i]);
            }
        }
        return temps;
    }

    public void ZombieStartMove()
    {
        for (int i = 0; i < zombies.Count; i++)
        {
            zombies[i].StartMove();
        }
    }

    /// <summary>
    /// 为关卡管理器检查所有僵尸死亡时的事件
    /// </summary>
    private void CheckAllZombieDeadForLV()
    {
        if (zombies.Count==0)
        {
            if (AllZombieDeadAction != null) AllZombieDeadAction();
        }
    }

    public void AddAllZombieDeadAction(UnityAction action)
    {
        AllZombieDeadAction += action;
    }
    public void RemoveAllZombieDeadAction(UnityAction action)
    {
        AllZombieDeadAction -= action;
    }
    /// <summary>
    /// 5秒进行一次，有一定概率播放呻吟音效
    /// </summary>
    private void Groan()
    {
        StartCoroutine(DoGroan());
    }
    IEnumerator DoGroan()
    {
        while (true)
        {
            // 有僵尸才进行随机
            if (zombies.Count>0)
            {
                // 如果随机数大于6则播放
                if (Random.Range(0,10)>6)
                {
                    AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ZombieGroan);
                }
            }
            yield return new WaitForSeconds(5);
        }
    }
}
