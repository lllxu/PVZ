using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CancleCard : MonoBehaviour
{
    public static CancleCard Instance;
    private GameObject maimPanel;
    private GameObject group;
    void Awake()
    {
        Instance = this;
        maimPanel = GameObject.Find("MainPanel");
        group = GameObject.Find("MainPanel/Group");

    }


    public void Cancle1Button()
    {
        Destroy(group.transform.GetChild(0).gameObject);
        ChoseCard.currentnum -= 1;
    }
    public void Cancle2Button()
    {
        Destroy(group.transform.GetChild(1).gameObject);
        ChoseCard.currentnum -= 1;
    }
    public void Cancle3Button()
    {
        Destroy(group.transform.GetChild(2).gameObject);
        ChoseCard.currentnum -= 1;
    }
    public void Cancle4Button()
    {
        Destroy(group.transform.GetChild(3).gameObject);
        ChoseCard.currentnum -= 1;
    }
    public void Cancle5Button()
    {
        Destroy(group.transform.GetChild(4).gameObject);
        ChoseCard.currentnum -= 1;
    }
    public void Cancle6Button()
    {
        Destroy(group.transform.GetChild(5).gameObject);
        ChoseCard.currentnum -= 1;
    }
    public void CancleAll()
    {
        for(int i = 0; i < ChoseCard.currentnum; i++)
        {
            Destroy(group.transform.GetChild(i).gameObject);
        }
        ChoseCard.currentnum -= 6;
    }
    
}
