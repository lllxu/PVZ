using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class ChoseCard : MonoBehaviour
{
    private bool isChose = false;
    public GameObject SunFlower;//ֲ�￨Ƭ��Ԥ����
    public GameObject WallNut;
    public GameObject Spike;
    public GameObject Peashooter;
    public GameObject Cherry;
    private GameObject group;
    private GameObject maimPanel;
    public GameObject Threepeater;
    public GameObject Torchwood;
    public GameObject Squash;
    public GameObject SnowPea;
    public GameObject Chomper;
    public GameObject BigChomper;
    public GameObject GatlingShooter;
    public GameObject Spikerock;
    public GameObject SunShroom;
    public GameObject TallWallNut;
    public GameObject TwinSunflower;
    public GameObject TenManNut;
    public GameObject SplitPea;
    public GameObject ScaredyShroom;
    private GameObject CurCard;
    public static int currentnum = 0;

    private void Awake()
    {
        
        maimPanel = GameObject.Find("MainPanel");
        group = GameObject.Find("MainPanel/Group");
    }
    public void SunFlowerButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(SunFlower);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void WallNutButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(WallNut);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void SpikeButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Spike);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void PeashooterButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Peashooter);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void CherryButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Cherry);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void ThreepeaterButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Threepeater);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void TorchwoodButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Torchwood);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void SquashButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Squash);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void SnowPeaButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(SnowPea);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void ChomperButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Chomper);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void BigChomperButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(BigChomper);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }
    }
    public void GatlingShooterButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(GatlingShooter);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void SpikerockButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(Spikerock);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void SunShroomButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(SunShroom);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void TallWallNutButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(TallWallNut);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void TwinSunflowerButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(TwinSunflower);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void TenManNutButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(TenManNut);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void ScaredyShroomButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(ScaredyShroom);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void SplitPeaButton()
    {
        if (currentnum < 6)
        {
            CurCard = Instantiate(SplitPea);
            CurCard.transform.parent = group.transform;
            currentnum += 1;
        }

    }
    public void startButtonClick()             //�£�ѡ��ֲ�����Ŀ�ս��ť
    {
        Time.timeScale = 1;
        //�ر�ѡ��ֲ�����
        UIManager.Instance.SetChoseCardActiv(false);
        UIManager.Instance.SetCancleCardActiv(false);
    }
    public void BackMainScene()
    {
        PoolManager.Instance.Clear();
        AudioManager.Instance.PlayEFAudio(GameManager.Instance.GameConf.ButtonClick);
        CancleCard.Instance.CancleAll();
        Time.timeScale = 1;
        Invoke("DoBackMainScene", 0);
    }

    private void DoBackMainScene()
    {
        SceneManager.LoadScene("Start");
    }

}
